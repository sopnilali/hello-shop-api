-- AlterTable
ALTER TABLE "users" ALTER COLUMN "phoneNumber" DROP NOT NULL,
ALTER COLUMN "address" DROP NOT NULL;
