-- AlterTable
ALTER TABLE "users" ADD COLUMN     "city" TEXT;
