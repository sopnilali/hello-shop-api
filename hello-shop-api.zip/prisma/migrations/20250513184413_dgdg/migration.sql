-- AlterTable
ALTER TABLE "orders" ALTER COLUMN "transactionId" DROP NOT NULL;
