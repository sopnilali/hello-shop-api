export const orderSearchAbleFields: string[] = ['email']; // only for search term

export const orderFilterableFields: string[]= [
    'transactionId',
    'status',
    'paymentMethod',
    'searchTerm'
]