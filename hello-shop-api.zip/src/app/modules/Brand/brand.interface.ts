export interface IBrand {
    id: string
    name: string
    description: string
    logo: string
    createdAt: string
    updatedAt: string
  }
  